# -*- coding: utf-8 -*-
import re
import sys
import os
import random
import urllib
import urllib2
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
#import xbmcvfs


__addon_id__= 'plugin.video.nova.play'
__Addon = xbmcaddon.Addon(__addon_id__)

#Прилага настройката за сортиране, според потребителските настройки
__settings__ = xbmcaddon.Addon(id='plugin.video.nova.play')
livest = __settings__.getSetting("livest")
if livest=='1':
	live="hls"
else:
	live="rtmp"
order = __settings__.getSetting("order")
if order=='0':
	sort="order=-visible_from"
else:
	sort="order=visible_from"

MUA = 'Mozilla/5.0 (Linux; Android 4.2.2; bg-bg; SAMSUNG GT-I9195 Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Version/1.0 Chrome/18.0.1025.308 Mobile Safari/535.19'
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:64.0) Gecko/20100101 Firefox/64.0'
thumbsize = '400x300'
md = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")
search_string = urllib.unquote_plus(__settings__.getSetting('lastsearch'))

#Основно меню
def CATEGORIES():
		addDir('Търсене на предаване','http://play.novatv.bg/tursene?term=',2,md+'DefaultAddonsSearch.png')
		#TV програма и обложка
		api = "http://nova.bg";
		opener = urllib2.build_opener()
		opener.addheaders = [('User-agent', UA)]
		data = opener.open(api).read()
		
		match = re.compile('<span class="live-info">(.+?)</span>').findall(data)
		for title in match:
			title = 'В момента по NOVA: ' + title
			addLink(title,title+'@'+'rtmp://edge1.cdn.bg:2010/fls/_definst_/ntv_2.stream pageUrl=http://i.cdn.bg/live/0OmMKJ4SgY token=N0v4TV6#2 timeout=12'+'@'+'http://logos.kodibg.org/novatv.png','',0,5,'http://logos.kodibg.org/novatv.png')
		
		#Списък с категории
		api = "http://play.novatv.bg/programi";
		opener = urllib2.build_opener()
		opener.addheaders = [('User-agent', UA)]
		data = opener.open(api).read()
		
		match = re.compile('href="(.+?)"\n.*\n.*\n.*\n.*\n.*\n.*\n.*clip-title-new">(.+?)<.*\n.*\n.*\n.*\n.*src="(.+?)"').findall(data)
		for url,name,thumbnail in match:
			thumbnail=thumbnail.replace('{size}',thumbsize)
			thumbnail=thumbnail.replace('http://cdn.playapi.mtgx.tv','http://i2.wp.com/cdn.playapi.mtgx.tv')
			addDir(name,url,1,thumbnail)



#Списък на заглавията в една категория
def INDEXCAT(url):
		href = url
		req = urllib2.Request(href)
		req.add_header('User-Agent', MUA)
		response = urllib2.urlopen(req)
		data=response.read()
		response.close()
		
		match = re.compile('href="(.+?)".*\n.*\n.*\n.*\n.*\n.*\n.*data-src="(.+?)".*\n.*\n.*\n.*\n.*>(.+?)<').findall(data)
		for adres,thumbnail,title in match:
			thumbnail=thumbnail.replace('{size}',thumbsize)
			thumbnail=thumbnail.replace('http://cdn.playapi.mtgx.tv','http://i1.wp.com/cdn.playapi.mtgx.tv')
			addDir(title,adres,6,thumbnail)


#Извличане ID на конкретно предаване
def INDEXSHOW(url):
	href = url
	req = urllib2.Request(href)
	req.add_header('User-Agent', MUA)
	response = urllib2.urlopen(req)
	data=response.read()
	response.close()
	
	match = re.compile('data-id="(.+?)" data-title="(.+?)"').findall(data)
	for showid,name in match[:len(match)/2:]:  #showid е сезон
		if len(match)==2: #Ако е наличен само един сезон, директно го отвори
			INDEXPAGES(showid)
		else:
			addDir(name,showid,3,md+'DefaultFolder.png')



#Разлистване епизодите/частите на отделно заглавие
def INDEXPAGES(showid):
		#print 'Order setting:' + sort
		if 'season' in showid:
			showid = re.compile('season=(.+?&page=\d)').findall(showid)[0]
		req = urllib2.Request('http://playapi.mtgx.tv/v3/videos?season=' + showid + '&' + sort)
		opener = urllib2.build_opener()
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['_embedded']['videos'][0]['title'].encode('utf-8', 'ignore')
		
		
		for episodes in range(0, len(jsonrsp['_embedded']['videos'])):
			vid = jsonrsp['_embedded']['videos'][episodes]['id']
			#print vid
			title = jsonrsp['_embedded']['videos'][episodes]['title'].encode('utf-8', 'ignore')
			#title = jsonrsp['_embedded']['videos'][episodes]['title'].encode('utf-8', 'ignore')
			#print title
				
			if jsonrsp['_embedded']['videos'][episodes]['format_position']['is_episodic']:
				season = jsonrsp['_embedded']['videos'][episodes]['format_position']['season']
				episode = jsonrsp['_embedded']['videos'][episodes]['format_position']['episode']
				
				if str(season) == 'None':
					season = '1'
				if 'епизод 1 и 2' in jsonrsp['_embedded']['videos'][episodes]['title'].encode('utf-8', 'ignore'):
					title = re.sub(r"( .епизод 1 и 2.)", "", jsonrsp['_embedded']['videos'][episodes]['title'].encode('utf-8', 'ignore')) + ' - сезон ' + str(season) + ' епизоди 1 и 2'
				else:
					if not episode.isdigit():
						title = re.sub(r"( .Сезон \d+.)|( епизод \d*)|( - епизод \d*)|( С\d+Е\d+)|(.S\d+Е\d+.)|(.S\d+E\d+)", "", jsonrsp['_embedded']['videos'][episodes]['title'].encode('utf-8', 'ignore')) + ' [сезон ' + str(season) + ']'
					else:
						title = re.sub(r"( .Сезон \d+.)|( епизод \d*)|( - епизод \d*)|( С\d+Е\d+)|(.S\d+Е\d+.)|(.S\d+E\d+)", "", jsonrsp['_embedded']['videos'][episodes]['title'].encode('utf-8', 'ignore')) + ' - сезон ' + str(season) + ' епизод ' + str(episode)
				title = title.replace(' - сезон 0 епизод 0','')
				#print title
				
			duration = jsonrsp['_embedded']['videos'][episodes]['duration']
			#print duration
			thumbnail = jsonrsp['_embedded']['videos'][episodes]['_links']['image']['href']
			thumbnail=thumbnail.replace('{size}',thumbsize)
			#thumbnail=thumbnail.replace('http://cdn.playapi.mtgx.tv','http://i0.wp.com/cdn.playapi.mtgx.tv')
			#print thumbnail
			
			addLink(title,str(vid)+'--'+thumbnail,'Видеото е достъпно за гледане до: '+str(jsonrsp['_embedded']['videos'][episodes]['unpublish_at']).replace('None','неопределено време'),str(duration),4,thumbnail)
		
		#Ако има следваща страница...
		try:
			nextpage = jsonrsp['_links']['next']['href']
			#print 'There is next page:' + nextpage
			addDir('следваща страница>>',nextpage,3,md+'DefaultFolder.png')
		except:
			pass


#Извличане на стрийм и стартиране
def VIDEOLINKS(name,url):
		link, cover = url.split("--")
		req = urllib2.Request('http://playapi.mtgx.tv/v3/videos/stream/' + link)
		opener = urllib2.build_opener()
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['streams']['medium']
		
		
		#Избор на стрийма с най-добро качество; HLS е със предимство
		try:
			if jsonrsp['streams']['hls'] <> 'null':
				playurl = jsonrsp['streams']['hls']
				playurl = playurl.replace('_m.mp4', '.mp4')
			else:
				if jsonrsp['streams']['high'] <> 'null':
					playurl = jsonrsp['streams']['high']
				else:
					playurl = jsonrsp['streams']['medium']
			if 'rtmp' in playurl:
				playurl = playurl.replace('rtmp://stream.novatv.bg/mediacache/mp4:http/', 'http://videobg.novatv.bg/')
				playurl = playurl.replace('rtmp://streambg.novatv.bg/mediacache/mp4:http/', 'http://videobg.novatv.bg/')
		except:
			playurl = jsonrsp['streams']['medium']
			playurl = playurl.replace('rtmp://stream.novatv.bg/mediacache/mp4:http/', 'http://videobg.novatv.bg/')
			playurl = playurl.replace('rtmp://streambg.novatv.bg/mediacache/mp4:http/', 'http://videobg.novatv.bg/')
		#print 'избраният стрийм линк е: ' + playurl


		
		#Възпроизвеждане на видеото
		li = xbmcgui.ListItem(iconImage=cover, thumbnailImage=cover, path=playurl+'|User-Agent=stagefright')
		li.setInfo('video', { 'title': name })
		try:
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
		except:
			xbmc.executebuiltin("Notification('Грешка','Видеото липсва на сървъра!')")


#Възпроизвеждане на онлайн стрийм "на живо" през loadbalancer
def STREAMPLAY(url):
		name, adres, thumb = url.split("@")
		if live == 'rtmp':    
			#Избиране на стрийминг сървър
			streamer = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14'] #, '15', '16', '17', '18', '19', '20'
			ns = random.choice(streamer)
			stream = re.sub(r"edge\d", "edge" + ns, adres)
		else:
			stream = 'http://ios.cdn.bg:2010/fls/ntv_1.stream/playlist.m3u8|User-Agent=Mozilla%2F5.0%20(iPhone%3B%20CPU%20iPhone%20OS%207_1_1%20like%20Mac%20OS%20X)%20AppleWebKit%2F537.51.2%20(KHTML%2C%20like%20Gecko)%20Version%2F7.0%20Mobile%2F11D201%20Safari%2F9537.53'
		li = xbmcgui.ListItem(iconImage=thumb, thumbnailImage=thumb, path=stream)
		li.setInfo('video', { 'title': name })
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)



#Търсене на предаване
def SEARCH(url):
		keyb = xbmc.Keyboard(search_string, 'Търсачка на предавания')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			searchText=searchText.replace(' ','+')
			if searchText == "":
				addDir('Върни се назад - няма резултати, съвпадащи с търсеното','','',md+'DefaultFolderBack.png')
			else:
				#Записване на заявката за търсене в настройките
				__settings__.setSetting('lastsearch', searchText)
			url= url + searchText
			url = url.encode('utf-8')
			#print 'SEARCHING:' + url
			INDEXCAT(url.lower())
		else:
			addDir('Върнете се назад в главното меню за да продължите','','',md+'DefaultFolderBack.png')


def addLink(name,url,plot,duration,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
		liz.setInfo( type="Video", infoLabels={ "title": name, "duration": duration, "plot": plot } )
		liz.addStreamInfo('video', { 'width': 640, 'height': 368 })
		liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok


def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok



def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass



if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		INDEXCAT(url)

elif mode==2:
		SEARCH(url)

elif mode==3:
		INDEXPAGES(url)
		
elif mode==4:
		VIDEOLINKS(name,url)

elif mode==5:
		STREAMPLAY(url)
		
elif mode==6:
		INDEXSHOW(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
