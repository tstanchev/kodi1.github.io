# -*- coding: utf-8 -*-
#Библиотеки, които използват python и Kodi в тази приставка
import re
import sys
import os
import urllib
import urllib2
import cookielib
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

#Място за дефиниране на константи, които ще се използват няколкократно из отделните модули
__addon_id__= 'plugin.video.filmboxlivebg'
__Addon = xbmcaddon.Addon(__addon_id__)
__settings__ = xbmcaddon.Addon(id='plugin.video.filmboxlivebg')
username = __settings__.getSetting('username')
password = __settings__.getSetting('password')
sessionid = __settings__.getSetting('sessionid')
userid = __settings__.getSetting('userid')
random = ''
checksum = ''
logged_in = False
cj = cookielib.CookieJar()
API = 'https://api.invideous.com'
PUB = '25138'
D = 'androidmobile'
UA = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0'
MUA = 'Dalvik/2.1.0 (Linux; U; Android 8.0.1; Redmi Note 3 MIUI/V9.1.2.0.OHNCNDI)'
PUA = 'MT6795_TD/V1 Linux/3.10.61+ Android/8.0.1 Release/ Browser/AppleWebKit Chrome/37.0.0.0 Mobile Safari/ System/Android 8.0.1'
md = xbmc.translatePath(__Addon.getAddonInfo('path') + "/resources/media/")


#Генериране на сесия
def LOGIN():
	global sessionid
	global userid
	global random
	global checksum
	global logged_in
	global cj
	
	try:
		req = urllib2.Request(API+'/plugin/login?username='+username+'&password='+password+'&platform=mobile')
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrspl = json.loads(f.read())
		#print jsonrspl['response']['result']['user_info']['id']
		#print jsonrspl['response']['result']['user_info']['session_id']
		#print jsonrspl['response']['result']['user_info']['random']
		#print jsonrspl['response']['result']['user_info']['checksum']
		
		try:
			userid = jsonrspl['response']['result']['user_info']['id']
			sessionid = jsonrspl['response']['result']['user_info']['session_id']
			random = jsonrspl['response']['result']['user_info']['random']
			checksum = jsonrspl['response']['result']['user_info']['checksum']
		except:
			pass
		
		try:
			if jsonrspl['response']['result']['user_info']['active'] == 1:
				#xbmcgui.Dialog().ok('Filmbox live',jsonrspl['response']['message'])
				xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(jsonrspl['response']['result']['user_info']['username'],'Време е за пуканки!', 4000, md+'DefaultUser.png'))
				logged_in = True
		except:
			#xbmcgui.Dialog().ok('Filmbox live',jsonrspl['response']['message'])
			xbmcgui.Dialog().ok('Влизането е неуспешно','Ако сте влезли от друго устройство, първо се отпишете в него и опитайте отново да се логнете тук. За всеки случай, проверете правилно ли сте въвели акаунта си!')
			xbmcaddon.Addon(id='plugin.video.filmboxlivebg').openSettings("Акаунт")
			xbmc.executebuiltin("Action(Back)")
			logged_in = False
		
	except:
		xbmcgui.Dialog().ok('Filmbox live','Възникна проблем в Login функцията. Съобщете на разработчика за проблема!')


#Меню с директории в приставката
def CATEGORIES():
		global logged_in
		if logged_in == False:
			LOGIN()
		
		global sessionid
		global userid
		global random
		global checksum
		global cj
		
		addDir('Търсачка','search',5,md+'DefaultAddonsSearch.png')
		addDir('Filmbox live','fcl',2,md+'DefaultFolder.png')
		
		#endpoint
		req = urllib2.Request('http://filmboxliveapp.net/cmsendpoint.json')
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		EP = jsonrsp['cmsendpoint']
		
		#Категории филми
		req = urllib2.Request(EP+'/getAllCategories?countryName=bg')
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['array'][0]['id']
		#print jsonrsp['array'][0]['name']
		#print jsonrsp['array'][0]['searchName']
		
		addDir('Сериали','SERIES&page=1',1,md+'DefaultFolder.png')
		for cat in range(0, len(jsonrsp)):
			addDir(jsonrsp[cat]['name'].encode('utf-8', 'ignore'),jsonrsp[cat]['searchName']+'&page=1',1,md+'DefaultFolder.png')
		
		

#Разлистване на категориите
def LIST(url):
		global cj
		req = urllib2.Request(API+'/plugin/get_packages?publisher_id='+PUB)
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['response']['result']['packages'][0]['id']
		
		#Разлистване
		req = urllib2.Request(API+'/plugin/get_package_videos?publisher_id='+PUB+'&package_id='+jsonrsp['response']['result']['packages'][0]['id']+'&custom_filter_by_genre='+url+'&custom_order_by_priority=asc')
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['response']['result']['videos'][0]['id']
		#print jsonrsp['response']['result']['videos'][0]['title']
		#print jsonrsp['response']['result']['videos'][0]['description']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['description_bul']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['description_en']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['duration']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['largeImage']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['lg_source_url']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['nexus_thumbnail']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['promoImage']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['thumbnail']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['title_bul']
		#print jsonrsp['response']['result']['videos'][0]['custom_attributes']['title_en']
		#print jsonrsp['response']['result']['total_pages']
		
		#print 'number of titles is '+str(len(jsonrsp['response']['result']['videos']))
		for titles in range(0, len(jsonrsp['response']['result']['videos'])):
			#jsonrsp['response']['result']['videos'][titles]['custom_attributes']['duration'] = "01:29"
			try:
				prod = sum(x * int(t) for x, t in zip([3600, 60, 1], jsonrsp['response']['result']['videos'][titles]['custom_attributes']['duration'].split(":")))
			except:
				prod = '5400'
			try:
				addLink(jsonrsp['response']['result']['videos'][titles]['custom_attributes']['title_bul'].encode('utf-8', 'ignore'),jsonrsp['response']['result']['videos'][titles]['source_url'],jsonrsp['response']['result']['videos'][titles]['custom_attributes']['description_bul'].encode('utf-8', 'ignore'),prod,4,jsonrsp['response']['result']['videos'][titles]['custom_attributes']['largeImage'])
			except:
				addLink(jsonrsp['response']['result']['videos'][titles]['custom_attributes']['title_en'].encode('utf-8', 'ignore'),jsonrsp['response']['result']['videos'][titles]['source_url'],jsonrsp['response']['result']['videos'][titles]['custom_attributes']['description_en'].encode('utf-8', 'ignore'),prod,4,jsonrsp['response']['result']['videos'][titles]['custom_attributes']['largeImage'])
				
			
		#Ако имаме още страници...
		#print jsonrsp['response']['result']['total_pages']
		current_page_number = re.search(r'\D(\d+)', url).group(1)
		if (int(current_page_number) < jsonrsp['response']['result']['total_pages']):
			next_page_number = str(int(current_page_number)+1)
			urln = re.search(r'(\D+)\d+', url).group(1) + next_page_number
			addDir('Към страница '+next_page_number+' от общо '+str(jsonrsp['response']['result']['total_pages'])+' >>>',urln,1,md+'DefaultFolder.png')
			
		
		
#Канали на живо
def FCL():
		global cj
		req = urllib2.Request('http://www.filmboxliveapp.net/channel/channels_bg.json')
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['channels'][0]['display_name']
		#print jsonrsp['channels'][0]['stream']
		#print jsonrsp['channels'][0]['images'][1]['image']
		for ch in range(0, len(jsonrsp['channels'])):
			addLink(jsonrsp['channels'][ch]['name'].encode('utf-8', 'ignore'),jsonrsp['channels'][ch]['stream'],'Гледай на живо през интернет от filmboxlive.com','',4,'http://www.filmboxliveapp.com/channel/'+jsonrsp['channels'][ch]['images'][1]['image'])
		
		
		
		
#Конкретно видео, TV или епизод
def CURRENT(url):
		global cj
		req = urllib2.Request(API+'/plugin/get_video_details?video_id='+url+'&session_id='+sessionid)
		req.add_header('User-Agent', PUA)
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
		f = opener.open(req)
		jsonrsp = json.loads(f.read())
		#print jsonrsp['response']['result']['title']
		#print jsonrsp['response']['result']['custom_attributes']['promoImage']
		#print jsonrsp['response']['result']['custom_attributes']['samsung_url']
		#print jsonrsp['response']['result']['source_url']
		
		#try:
		PLAY(jsonrsp['response']['result']['title'].encode('utf-8', 'ignore'),jsonrsp['response']['result']['source_url'],jsonrsp['response']['result']['custom_attributes']['promoImage'])
		#addLink(jsonrsp['response']['result']['title'].encode('utf-8', 'ignore'),jsonrsp['response']['result']['custom_attributes']['samsung_url'],3600,4,jsonrsp['response']['result']['custom_attributes']['promoImage'])



		


#Търсачка
def SEARCH():
		global cj
		keyb = xbmc.Keyboard('', 'Search')
		keyb.doModal()
		searchText = ''
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText())
			#searchText=searchText.replace(' ','+')
			
			req = urllib2.Request('http://www.filmboxlive.com/bg/movie/searchhelper?term='+searchText)
			req.add_header('User-Agent', UA)
			opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
			f = opener.open(req)
			jsonrsp = json.loads(f.read())        
			#print jsonrsp
			
			br=0
			for index in range(0, len(jsonrsp)):
				#print jsonrsp[index]['Id']
				#print jsonrsp[index]['Title']
				#print jsonrsp[index]['OriginalTitle']
				#print jsonrsp[index]['Description']
				#print jsonrsp[index]['Cast']
				#print jsonrsp[index]['Director']
				#print jsonrsp[index]['Duration']
				#print jsonrsp[index]['Genres']
				#print jsonrsp[index]['Genres_EN']
				#print jsonrsp[index]['YearOfProduction']
				#print jsonrsp[index]['LargeImageUrl']
				
				try:
					prod = sum(x * int(t) for x, t in zip([3600, 60, 1], jsonrsp['response']['result']['videos'][titles]['custom_attributes']['duration'].split(":")))
				except:
					prod = '5400'
				
				#addLink(jsonrsp['channels'][ch]['name'].encode('utf-8', 'ignore'),jsonrsp['channels'][ch]['stream'],'Гледай на живо през интернет от filmboxlive.com','',4,'http://www.filmboxliveapp.com/channel/'+jsonrsp['channels'][ch]['images'][1]['image'])
				addLink(jsonrsp[index]['Title'].encode('utf-8', 'ignore'),str(jsonrsp[index]['Id']),jsonrsp[index]['Description'].encode('utf-8', 'ignore'),prod,6,jsonrsp[index]['LargeImageUrl'])
				br=br+1
			if br==0:
				addDir('Go back - there are no results','','',md+'DefaultFolderBack.png')




#Зареждане на видео
def PLAY(name,url,iconimage):
		global sessionid
		global userid
		global logged_in
		global cj
		#if logged_in == False:
		#	LOGIN()
		
		#Проследяваме стрийма до крайния му адрес
		finalurl = url
		try:
			headers = urllib.urlencode({'User-Agent': PUA, 'Referer': API})
			req = urllib.urlopen(url, headers)
			finalurl = req.geturl()
		except:
			pass
		
		#HLS и  MP4 стриймове
		if (('m3u8' in url) or ('m3u8' in finalurl) or ('mp4' in url) or ('mp4' in finalurl)):
			
			#Проверка на клиентското IP
			req = urllib2.Request('http://mip.filmboxlive.com/CountryService.svc/CheckCountry')
			req.add_header('User-Agent', PUA)
			opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
			f = opener.open(req)
			jsonrsp = json.loads(f.read())
			IP = str(jsonrsp['ClientIP'])
			
			#Генериране на индивидуален сесиен тоукън
			#s = 'http://key.erstream.com/api/ticket/create?url='+url+'&clientip='+IP+'&key='+sessionid+'&userid='+userid+'&device='+D+'&domain=Filmbox'
			#xbmcgui.Dialog().ok('Filmbox live',s)
			#Get play tokens
			#print 'http://key.erstream.com/api/ticket/create?url='+finalurl+'&clientip='+IP+'&key='+sessionid+'&userid='+userid+'&device='+D+'&domain=Filmbox'
			req = urllib2.Request('http://key.erstream.com/api/ticket/create?url='+finalurl+'&clientip='+IP+'&key='+sessionid+'&userid='+userid+'&device='+D+'&domain=Filmbox')
			req.add_header('User-Agent', PUA)
			req.add_header('Referer', url)
			response = urllib2.urlopen(req)
			#print 'request page url:' + url
			data=response.read()
			response.close()
			#print data
			
			#http://AAA111BBB222...mp4?st=CfUkgvD8ScLsdh_O3IsZAQ&e=1508695371&domain=filmbox&device=webandroidmobile&userID=423...
			fullurl = url + '?' + data + '&device=androidmobile&userID='+userid+'&domain=filmbox'
			
			#Възпроизвеждане на видеото
			li = xbmcgui.ListItem(iconImage=iconimage, thumbnailImage=iconimage, path=fullurl+'|User-Agent='+urllib.quote_plus(PUA))
			li.setInfo('video', { 'title': name })
			#if logged_in == True:
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
			#else:
			#	xbmcgui.Dialog().ok('Filmbox live','Не сте вписани в услугата.')
		
		#HDS стриймове
		if 'manifest.f4m' in finalurl:
			#Възпроизвеждане на видеото
			#http://w-bk1.ercdn.net/filmbox/_definst_/smil:o/oR/AAA111BBB222CCC333...high.smil/manifest.f4m
			from resources.lib.f4mproxy.F4mProxy import f4mProxyHelper
			f4mp=f4mProxyHelper()
			#if logged_in == True:
			f4mp.playF4mLink(finalurl,name,proxy=None,use_proxy_for_chunks=False,maxbitrate=0,simpleDownloader=False,auth=None,streamtype='HDS',setResolved=False,swf=None,callbackpath="",callbackparam="",iconImage=iconimage)
			#else:
			#	xbmcgui.Dialog().ok('Filmbox live','Не сте вписани в услугата.')
			
			
			
			
			



#Модул за добавяне на отделно заглавие и неговите атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addLink(name,url,descr,vd,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name)
		liz.setArt({ 'thumb': iconimage,'poster': iconimage, 'banner' : iconimage, 'fanart': iconimage })
		liz.setInfo( type="Video", infoLabels={ "Duration": vd } )
		liz.setInfo( type="Video", infoLabels={ "Plot": descr } )
		if 'HD' in name:
			liz.addStreamInfo('video', { 'width': 1280, 'height': 720 })
			liz.addStreamInfo('video', { 'aspect': 1.78, 'codec': 'h264' })
		else:
			liz.addStreamInfo('video', { 'width': 720, 'height': 480 })
			liz.addStreamInfo('video', { 'aspect': 1.5, 'codec': 'h264' })
		liz.addStreamInfo('audio', { 'codec': 'aac', 'channels': 2 })
		liz.setProperty("IsPlayable" , "true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
		return ok

#Модул за добавяне на отделна директория и нейните атрибути към съдържанието на показваната в Kodi директория - НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def addDir(name,url,mode,iconimage):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage=md+'DefaultFolder.png', thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok


#НЯМА НУЖДА ДА ПРОМЕНЯТЕ НИЩО ТУК
def get_params():
		param=[]
		paramstring=sys.argv[2]
		if len(paramstring)>=2:
				params=sys.argv[2]
				cleanedparams=params.replace('?','')
				if (params[len(params)-1]=='/'):
						params=params[0:len(params)-2]
				pairsofparams=cleanedparams.split('&')
				param={}
				for i in range(len(pairsofparams)):
						splitparams={}
						splitparams=pairsofparams[i].split('=')
						if (len(splitparams))==2:
								param[splitparams[0]]=splitparams[1]
								
		return param



params=get_params()
url=None
name=None
iconimage=None
mode=None

try:
		url=urllib.unquote_plus(params["url"])
except:
		pass
try:
		name=urllib.unquote_plus(params["name"])
except:
		pass
try:
		name=urllib.unquote_plus(params["iconimage"])
except:
		pass
try:
		mode=int(params["mode"])
except:
		pass


#Списък на отделните подпрограми/модули в тази приставка - трябва напълно да отговаря на кода отгоре
if mode==None or url==None or len(url)<1:
		CATEGORIES()
	
elif mode==1:
		LIST(url)

elif mode==2:
		FCL()

elif mode==3:
		LOGIN()

elif mode==4:
		PLAY(name,url,iconimage)

elif mode==5:
		SEARCH()

elif mode==6:
		CURRENT(url)


xbmcplugin.endOfDirectory(int(sys.argv[1]))
